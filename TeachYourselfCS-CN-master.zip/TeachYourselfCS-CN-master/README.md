# TeachYourselfCS-CN

[![License](https://img.shields.io/github/license/keithnull/TeachYourselfCS-CN)](https://github.com/keithnull/TeachYourselfCS-CN/blob/master/LICENSE)

[TeachYourselfCS](https://teachyourselfcs.com/) 的中文翻译。

A Chinese translation of [TeachYourselfCS](https://teachyourselfcs.com/).

## 导航 Navigation

* [原网页 Original](https://teachyourselfcs.com/)
* [中文翻译 Chinese](TeachYourselfCS-CN.md)
* [英文原版 English](TeachYourselfCS.md)
